<?php
$username = $_POST['name'];
$password = $_POST['password'];

 //ctoney ctoney123
 if ($username =='ctoney' AND $password=='ctoney123') {
    echo "You have logged in!";
}
 if ($username =='croney' AND $password=='ctoney123') {
    echo "you have logged in!";
 }

 else {
    echo "You have not requested a login form!";
} 

?>
